from project.person import Person
from project.employee import Employee


class Teacher(Person, Employee):

    @staticmethod
    def teach():
        return "teaching..."


# teacher = Teacher()
# print(teacher.teach())
# print(teacher.sleep())
# print(teacher.get_fired())