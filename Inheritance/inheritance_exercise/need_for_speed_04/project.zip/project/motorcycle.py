# from Inheritance.inheritance_exercise.need_for_speed_04.project.vehicle import Vehicle
from project.vehicle import Vehicle


class Motorcycle(Vehicle):
    pass
