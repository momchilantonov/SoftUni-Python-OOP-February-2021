# from Inheritance.inheritance_exercise.need_for_speed_04.project.car import Car
from project.car import Car


class FamilyCar(Car):
    pass
