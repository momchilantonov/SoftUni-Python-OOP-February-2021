# from beverage import Beverage
from project.beverage.beverage import Beverage


class ColdBeverage(Beverage):
    pass
