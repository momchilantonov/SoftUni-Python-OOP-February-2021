# from Inheritance.inheritance_exercise.person_01.project.person import Person
from project.person import Person


class Child(Person):
    pass
