# from Inheritance.inheritance_exercise.zoo_02.project.animal import Animal
from project.animal import Animal


class Mammal(Animal):
    pass
